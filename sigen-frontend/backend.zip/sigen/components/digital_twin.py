# sigen-frontend/sigen/components/digital_twin.py
import reflex as rx
from sigen.styles import CARD_BG, CARD_BORDER, MUTED_TEXT, TEXT_COLOR

def digital_twin(estado: str, temp: float, rpm: float, voltaje: float, combustible: float) -> rx.Component:
    """Gemelo Digital 2D con animaciones e indicadores integrados."""
    
    # Colores base según estado
    primary_color = rx.cond(
        estado == "normal", "#10B981",
        rx.cond(estado == "precaucion", "#F59E0B",
        rx.cond(estado == "alerta", "#F97316", "#EF4444"))
    )
    
    # Velocidad de animación estática por ahora para evitar problemas de tipos con rx.Var
    anim_duration = "1s"
    
    twin_html = f"""
    <div style="position: relative; width: 100%; max-width: 500px; margin: 0 auto; padding: 2rem;">
        <svg viewBox="0 0 400 250" xmlns="http://www.w3.org/2000/svg">
            <!-- Chasis Base -->
            <rect x="20" y="50" width="360" height="150" rx="15" fill="#1E293B" stroke="rgba(255,255,255,0.1)" stroke-width="2"/>
            
            <!-- Panel de Control (derecha) -->
            <rect x="280" y="70" width="80" height="110" rx="5" fill="#0F172A" stroke="rgba(255,255,255,0.05)" stroke-width="1"/>
            <circle cx="320" cy="100" r="15" fill="#10B981" />
            <text x="320" y="105" fill="white" font-size="10" text-anchor="middle" font-family="sans-serif">ON</text>
            
            <!-- Indicador Digital de Voltaje -->
            <rect x="290" y="130" width="60" height="25" rx="3" fill="#000" />
            <text x="320" y="147" fill="{primary_color}" font-size="12" font-family="monospace" text-anchor="middle" font-weight="bold">{voltaje}V</text>
            
            <!-- Motor Principal (centro) -->
            <rect x="150" y="80" width="100" height="90" rx="10" fill="#334155" />
            <path d="M 150 100 L 250 100 M 150 120 L 250 120 M 150 140 L 250 140" stroke="#1E293B" stroke-width="4"/>
            <!-- Calor del Motor (opacidad basada en temp) -->
            <circle cx="200" cy="125" r="30" fill="url(#heatGrad)" opacity="0.6"/>
            
            <!-- Radiador y Ventilador (izquierda) -->
            <rect x="40" y="70" width="80" height="110" rx="5" fill="#0F172A" />
            <g style="transform-origin: 80px 125px; animation: spin {anim_duration} linear infinite;">
                <circle cx="80" cy="125" r="35" fill="none" stroke="#475569" stroke-width="2"/>
                <path d="M 80 90 L 80 160 M 45 125 L 115 125 M 55 100 L 105 150 M 55 150 L 105 100" stroke="#94A3B8" stroke-width="4"/>
            </g>
            
            <!-- Tanque de Combustible (Abajo) -->
            <rect x="40" y="210" width="320" height="20" rx="5" fill="#0F172A" />
            <rect x="40" y="210" width="calc({combustible} * 3.2)" height="20" rx="5" fill="{primary_color}" opacity="0.8"/>
            <text x="200" y="224" fill="white" font-size="10" font-family="sans-serif" text-anchor="middle">{combustible}% Combustible</text>

            <defs>
                <radialGradient id="heatGrad">
                    <stop offset="0%" stop-color="#EF4444" />
                    <stop offset="100%" stop-color="transparent" />
                </radialGradient>
            </defs>
            <style>
                @keyframes spin {{ 100% {{ transform: rotate(360deg); }} }}
            </style>
        </svg>
    </div>
    """
    
    return rx.box(
        rx.html(twin_html),
        background=CARD_BG,
        border=CARD_BORDER,
        border_radius="16px",
        width="100%",
        padding="1rem",
        box_shadow="inset 0 2px 10px rgba(0,0,0,0.2)"
    )
