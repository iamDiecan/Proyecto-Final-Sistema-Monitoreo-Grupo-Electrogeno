# sigen-frontend/sigen/state/alert_state.py
import reflex as rx
import httpx
from typing import List, Dict, Any
from sigen.state.auth_state import AuthState

class AlertState(rx.State):
    """Estado global para el Centro de Alertas."""
    alerts: List[Dict[str, Any]] = []
    
    async def fetch_alerts(self):
        """Obtiene todas las alertas activas desde la API."""
        auth_token = await self.get_state(AuthState)
        token = auth_token.token
        
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8001/api/alerts/?limit=100",
                    headers={"Authorization": f"Bearer {token}"}
                )
                if response.status_code == 200:
                    data = response.json()
                    
                    # Normalizar para el componente de tabla
                    normalized = []
                    for d in data:
                        normalized.append({
                            "id": d.get("id"),
                            "title": d.get("title", "Alerta"),
                            "level": d.get("level", "INFO"),
                            "node": d.get("node_id", "Unknown"),
                            "status": d.get("status", "activa")
                        })
                    self.alerts = normalized
                else:
                    self.alerts = []
        except Exception as e:
            print(f"Error fetching alerts: {e}")
            self.alerts = []
