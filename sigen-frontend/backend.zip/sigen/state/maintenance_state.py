# sigen-frontend/sigen/state/maintenance_state.py
import reflex as rx
import httpx
from typing import List, Dict, Any
from sigen.state.auth_state import AuthState

class MaintenanceState(rx.State):
    """Estado global para Mantenimiento."""
    records: List[Dict[str, Any]] = []
    
    async def fetch_records(self):
        """Obtiene el historial de mantenimiento desde la API."""
        auth_token = await self.get_state(AuthState)
        token = auth_token.token
        
        try:
            async with httpx.AsyncClient() as client:
                # Simulamos la consulta al nodo 01 para obtener datos
                response = await client.get(
                    "http://localhost:8001/api/maintenance/node/nodo_01",
                    headers={"Authorization": f"Bearer {token}"}
                )
                if response.status_code == 200:
                    data = response.json()
                    # Formatear la fecha
                    for d in data:
                        if "fecha" in d:
                            d["fecha"] = d["fecha"][:10]
                    self.records = data
                else:
                    self.records = []
        except Exception as e:
            print(f"Error fetching maintenance: {e}")
            self.records = []
