# sigen-frontend/sigen/pages/map.py
import reflex as rx
from sigen.templates.template import template
from sigen.styles import CARD_BG, CARD_BORDER, TEXT_COLOR, MUTED_TEXT

def map_page() -> rx.Component:
    """Mapa interactivo de nodos en Formosa."""
    # Usaremos un iframe que carga un mapa estático por ahora, o Leaflet inyectado en un div
    # Reflex html component
    
    leaflet_html = """
    <div id="map" style="height: 600px; width: 100%; border-radius: 12px; z-index: 1;"></div>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        window.leafletMap = null;
        window.leafletMarkers = [];
        
        setTimeout(() => {
            window.leafletMap = L.map('map').setView([-26.18489, -58.17313], 7);
            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(window.leafletMap);
        }, 500);

        window.updateMapMarkers = function(nodes) {
            if (!window.leafletMap) return;
            // Clear existing markers
            window.leafletMarkers.forEach(m => window.leafletMap.removeLayer(m));
            window.leafletMarkers = [];
            
            // Add new markers
            nodes.forEach(node => {
                let color = '#10B981'; // normal
                if (node.estado === 'alerta') color = '#EF4444';
                else if (node.estado === 'precaucion') color = '#F59E0B';
                
                let marker = L.circleMarker([node.lat, node.lon], {
                    color: color, 
                    radius: 8,
                    fillOpacity: 0.8
                }).bindPopup(`<b>${node.nombre}</b><br>Estado: ${node.estado}<br>Salud: ${node.health_score}%`);
                
                marker.addTo(window.leafletMap);
                window.leafletMarkers.push(marker);
            });
        };
    </script>
    """

    return template(
        rx.vstack(
            rx.heading("Mapa Provincial de Nodos", size="8", margin_bottom="1rem", color=TEXT_COLOR),
            rx.text("Vista geográfica en tiempo real del estado de los grupos electrógenos.", color=MUTED_TEXT, margin_bottom="2rem"),
            
            rx.box(
                rx.html(leaflet_html),
                background=CARD_BG,
                border=CARD_BORDER,
                padding="1rem",
                border_radius="16px",
                width="100%",
                box_shadow="0 8px 32px 0 rgba(0, 0, 0, 0.3)"
            )
        )
    )
