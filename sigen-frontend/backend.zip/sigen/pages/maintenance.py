# sigen-frontend/sigen/pages/maintenance.py
import reflex as rx
from typing import List, Dict, Any
from sigen.templates.template import template
from sigen.styles import CARD_BG, CARD_BORDER, TEXT_COLOR, MUTED_TEXT
from sigen.state.maintenance_state import MaintenanceState

def record_row(record: dict) -> rx.Component:
    return rx.table.row(
        rx.table.cell(record["nodo"], font_weight="bold"),
        rx.table.cell(record["fecha"]),
        rx.table.cell(rx.badge(record["tipo"], color_scheme="blue")),
        rx.table.cell(record["tecnico"]),
        rx.table.cell(f'{record["horas"]} h'),
    )

def maintenance() -> rx.Component:
    """Gestión de Mantenimiento Predictivo."""
    return template(
        rx.vstack(
            rx.heading("Mantenimiento Predictivo", size="8", margin_bottom="1rem", color=TEXT_COLOR),
            rx.text("Historial y predicción de servicios a los grupos electrógenos.", color=MUTED_TEXT, margin_bottom="2rem"),
            
            rx.box(
                rx.hstack(
                    rx.heading("Historial de Servicios", size="5", color=TEXT_COLOR),
                    rx.spacer(),
                    rx.button("Registrar Servicio", icon="plus", color_scheme="green", variant="soft"),
                    width="100%",
                    align="center",
                    margin_bottom="1rem"
                ),
                rx.table.root(
                    rx.table.header(
                        rx.table.row(
                            rx.table.column_header_cell("Nodo"),
                            rx.table.column_header_cell("Fecha"),
                            rx.table.column_header_cell("Tipo"),
                            rx.table.column_header_cell("Técnico"),
                            rx.table.column_header_cell("Horas Motor"),
                        )
                    ),
                    rx.table.body(
                        rx.foreach(MaintenanceState.records, record_row)
                    ),
                    variant="surface",
                    size="2",
                    width="100%"
                ),
                background=CARD_BG,
                border=CARD_BORDER,
                padding="1.5rem",
                border_radius="16px",
                width="100%"
            )
        )
    )
